<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="index.css">
    <title>Document</title>
    <style>
    body
    {
      background: #000;
    }
  </style>
  
<!-- header-->
<div id="header">
<img src="Capture.JPG">
    <!--navigation-->
    <div class="navscroll">
            <nav>
              <div class="title">
                  <h2> MATHARE LAW FIRM </h2>
              </div>
              
              <ul class="navlinks">
            
                <li><a href="index.php">Home</a></li>
                <li><a href="practice.php">practice area</a></li>
                <li><a href="connect.php">About Us</a></li>
                <li><a href="case.php">case</a></li>
                <li><a href="service.html">Service</a></li>
                <li><a href="contact.php">Contant us</a></li>
                <li>
                
                <a href="">
                  <P>Login <i class="fa fa-caret-down" aria-hidden="true"></i></p>
                </a>
                
                <ul>
                  <li><a href="connects.php">Client</a></li>
                  <li><a href="connect.php">Advocate</a></li>
                  <li><a href="loginc.php">Admin</a></li>
                </ul>
              </li>
              </ul>
              <div class="mobile">
                  <div class="line1"></div>
                  <div class="line2"></div>
                  <div class="line3"></div>
              </div>
          </nav>
          </div>
          <script src="index.js"></script>
</head>
<body>
<div class="home">
    <p> we offer legal advice and aid in solving problems regarding procedures of the law</p>
    <h3>you've ideas  " We Protect them" </h3>
    <h2>The emancipators Advocates</h2>
</div>
</body>
<footer>
        <div class="footer-container">
            <div class="footer">
                <div class="footer-heading footer-1">
                    <h2>About Us</h2>
                    <a href="try.html">Vacancy</a>
                    <a href="#">Opportunities</a>
                    <a href="#">Appointments</a>
                    
                </div>
                <div class="footer-heading footer-2">
                    <h2>Social Media</h2>
                    <a href="#">Facebook</a>
                    <a href="#">Twitter</a>
                    <a href="#">Instagram</a>
                    
                </div>
                <div class="footer-heading footer-3">
                    <h2>Contact Us</h2>
                    <a href="#">Blog</a>
                    <a href="terms.html">Terms and Services</a>
                    <a href="#">sponsorship</a>
                    
                </div>
                <div class="footer-email-form">
                    <h2>Join our E-team service</h2>
                    <input type="email" placeholder="Enter your email address" id="footer-email">
                    <input type="submit" value="sign up" id="footer-email-btn">
                </div>

            </div>
           
        </div>

    </footer>
</html>