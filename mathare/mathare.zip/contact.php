<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="index.css">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <title>Document</title>
    <style>
    body
    {
      background: #000;
      min-height: 100vh;
    background:url(image1.JPEG) no-repeat;
    background-size: cover;
    }
  </style>
  <!-- header-->
<div id="header">
<img src="Capture.JPG">
    <!--navigation-->
    <div class="navscroll">
            <nav>
              <div class="title">
                  <h2> MATHARE LAW FIRM </h2>
              </div>
              
              <ul class="navlinks">
            
                <li><a href="index.php">Home</a></li>
                <li><a href="practice.php">practice area</a></li>
                <li><a href="About.html">About Us</a></li>
                <li><a href="service.html">Service</a></li>
                <li><a href="contact.php">Contant us</a></li>
                <li>
                
                <a href="">
                  <P>Login <i class="fa fa-caret-down" aria-hidden="true"></i></p>
                </a>
                
                <ul>
                  <li><a href="loginu.php">Client</a></li>
                  <li><a href="logina.php">Advocate</a></li>
                  <li><a href="loginc.php">Admin</a></li>
                </ul>
              </li>
              </ul>
              <div class="mobile">
                  <div class="line1"></div>
                  <div class="line2"></div>
                  <div class="line3"></div>
              </div>
          </nav>
          </div>
          <script src="index.js"></script>

</head>
<body>
   <!--Contact Section-->
   <div class="cont-section">
        <div class="cont-info">
            <div><i class="fa fa-map-marker" aria-hidden="true" style="font-size:28px;color:teal;"></i>Mathare, Nairobi</div>
            <div><i class="fa fa-phone" aria-hidden="true" style="font-size:28px;color:teal;"></i>+254 -72312902</div>
            <div><i class="fa fa-envelope" aria-hidden="true" style="font-size:28px;color:teal;"></i>mathareg@gmail.com</div>
            <div><i class="fa fa-clock-o" aria-hidden="true" style="font-size:28px;color:teal;"></i>Mon- Fri 8:00 AM to 5:00 PM, Sat 8:30 AM to 2:00 PM</div>
        </div>
         <div class="cont-form">
             <h2>Contact Us</h2>
             <form action="">
                 <input type="text" name="name" class="text-box" placeholder="Your Name" required="required">
                 <input type="text" name="email" class="text-box" placeholder="Your Email" required="required">
                 <textarea name="name" id="" cols="30" rows="10"></textarea>
                 <input type="submit" name="submit" class="send-btn" value="Send">
                </form>
         </div>   
        </div> 
</body>
</html>